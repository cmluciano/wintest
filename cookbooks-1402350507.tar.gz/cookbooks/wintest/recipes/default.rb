#
# Cookbook Name:: wintest
# Recipe:: default
#
# Copyright (C) 2014 YOUR_NAME
#
# All rights reserved - Do Not Redistribute
#

windows_feature "Web-Server" do
  action :install
end
